# mongoDB-learn
 Just tryna learn mongoDB
